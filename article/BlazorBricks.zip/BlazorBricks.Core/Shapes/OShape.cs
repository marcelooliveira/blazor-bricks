using System;
using System.Collections.Generic;
using System.Text;

namespace BlazorBricks.Core.Shapes
{
    public class OShape : BaseShape
    {
        public OShape() : base(2, 2, "1111", ShapeCode.O)
        {
        }
    }
}
