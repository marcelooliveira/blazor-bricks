using System;
using System.Collections.Generic;
using System.Text;

namespace BlazorBricks.Core.Shapes
{
    public class TShape : BaseShape
    {
        public TShape(): base(3, 2, "111010", ShapeCode.T)
        {
        }
    }
}
