using System;
using System.Collections.Generic;
using System.Text;

namespace BlazorBricks.Core.Shapes
{
    public class SShape : BaseShape
    {
        public SShape() : base(3, 2, "011110", ShapeCode.S)
        {
        }
    }
}
