using System;
using System.Collections.Generic;
using System.Text;

namespace BlazorBricks.Core.Shapes
{
    public class JShape : BaseShape
    {
        public JShape() : base(3, 2, "100111", ShapeCode.J)
        {
        }
    }
}
